document.addEventListener('DOMContentLoaded', function () {
  const apiUrl = 'https://jsonserver-partidas-1.nayarissonnatan.repl.co/users/';

  const emailElement = document.querySelector('.negrito:nth-child(2) p');
  const usernameElement = document.querySelector('.negrito:nth-child(4) p');
  const phoneElement = document.querySelector('.negrito:nth-child(6) p');
  const passwordElement = document.querySelector('.negrito:nth-child(8) p');
  const genderElement = document.querySelector('.negrito:nth-child(10) p');

  fetch(apiUrl)
    .then(response => response.json())
    .then(data => {
      emailElement.textContent = data.email;
      usernameElement.textContent = data.username;
      phoneElement.textContent = data.phone;
      passwordElement.textContent = data.password;
      genderElement.textContent = data.gender;
    })
    .catch(error => console.error('Erro ao buscar dados do usuário:', error));
});